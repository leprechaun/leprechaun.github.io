{{/*
Expand the name of the chart.
*/}}
{{- define "owntracks-reporter.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "owntracks-reporter.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "owntracks-reporter.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "owntracks-reporter.labels" -}}
helm.sh/chart: {{ include "owntracks-reporter.chart" . }}
{{ include "owntracks-reporter.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "owntracks-reporter.selectorLabels" -}}
app.kubernetes.io/name: {{ include "owntracks-reporter.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "owntracks-reporter.dataPVCName" -}}
{{- printf "owntracks-data-%s-0" (include "owntracks-reporter.fullname" .) -}}
{{- end }}

{{- define "owntracks-reporter.s3SyncSecretName" -}}
{{- if .Values.s3Sync.existingSecret -}}
{{- .Values.s3Sync.existingSecret -}}
{{- else -}}
{{- printf "%s-s3sync" (include "owntracks-reporter.fullname" .) -}}
{{- end -}}
{{- end }}
